﻿using Amazon.Lambda.Core;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;


namespace Xcube_File_Move
{
    public class XcubeApi
    {
        private string apiurl = Environment.GetEnvironmentVariable("apiurl"); //"https://uat1xviewintegration.drlallab.com/v1";//
        private string apikey = Environment.GetEnvironmentVariable("apikey");//"88cd2c87-2451-43d2-a238-38647cdaf2ba";

        public dynamic PushMetaData(dynamic objectrquest, ILambdaContext context, out HttpStatusCode statuscode)
        {
            Functions obj = new Functions();
            dynamic result = null;
            var jsonorderrequest = "";
            HttpWebResponse httpResponse = null;
            try
            {
              
                jsonorderrequest = JsonConvert.SerializeObject(objectrquest);
                context.Logger.Log("--Request--");
                context.Logger.Log(jsonorderrequest);
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(apiurl + "/ecommerce/etrf");
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add("x-api-key", apikey);
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    streamWriter.Write(jsonorderrequest);
                    streamWriter.Flush();
                    streamWriter.Close();

                }
                httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {

                    result = streamReader.ReadToEnd();
                }
                statuscode = httpResponse.StatusCode;
              
               // obj.createlog("--Request--" + jsonorderrequest+"\n--Response--" + result);

                context.Logger.Log("Api Response:, Result:" + result);

            }
            catch (WebException ex)
            {
                using (var streamReader = new StreamReader(ex.Response.GetResponseStream()))
                {
                    result = streamReader.ReadToEnd();
                }
                statuscode = httpResponse.StatusCode;
                context.Logger.Log("Api Response:" + ex.Message + " , Result:" + result);
               // obj.createlog("--Request--" + jsonorderrequest + "\n--Response--" + result);
            }

            return result;
        }

    }


    public class requestdata
    {
        public attributes attributes { get; set; }

    }
    public class attributes
    {
        public string lab_code { get; set; }

        public string file_path { get; set; }

        public string lab_number { get; set; }
    }
}
