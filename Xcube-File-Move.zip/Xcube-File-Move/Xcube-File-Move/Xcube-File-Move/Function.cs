using System.Collections.Generic;
using System.Linq;
using System.Net;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using Microsoft.AspNetCore.StaticFiles;
// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace Xcube_File_Move
{
    public class Functions
    {
        private string sourcebucket = Environment.GetEnvironmentVariable("sourcebucket");//"lalpathlabs-reports-temp1";
        private string destinationbucket =  Environment.GetEnvironmentVariable("destinationbucket"); //"xcube-csv-files111";
        private string sourceprefix = Environment.GetEnvironmentVariable("sourceprefix");//FarEye ;
        private string destinationprefix = Environment.GetEnvironmentVariable("destinationprefix");//FarEye;
        private string logbucket = Environment.GetEnvironmentVariable("logbucket");//"logsx";
        private static readonly RegionEndpoint bucketRegion = RegionEndpoint.APSouth1;
        private static IAmazonS3 s3Client;

        public dynamic Get(dynamic request, ILambdaContext context)
        {

            Console.WriteLine("Lamda started");
            Console.WriteLine("request:  " + JsonConvert.SerializeObject(request));

            try
            {
                string serializereq = JsonConvert.SerializeObject(request);
                if (request != null && serializereq.Contains("object"))
                {
                  string keys=  Convert.ToString(request.Records[0].s3.@object.key);
                    string[] objectList = keys.Split("/");
                    if (objectList.Length >= 3)
                    {
                        // request = "FarEye/A45/HP_BNR_LPL_F1-05.jpg";
                                             
                        s3Client = new AmazonS3Client(bucketRegion);
                        Task<APIGatewayProxyResponse> results = CopyingObjectAsync(request, context);
                        Console.WriteLine(results.Result.Body);
                        Console.WriteLine("Lamda finished");
                        return results.Result;
                    }
                    else
                    {
                        APIGatewayProxyResponse res = new APIGatewayProxyResponse();
                        Console.WriteLine("request:  " + JsonConvert.SerializeObject(request));

                        Console.WriteLine("Lamda finished");
                        res.Body = "Request is Invalid";
                        return res;
                    }
                }
                else
                {
                   
                    APIGatewayProxyResponse res = new APIGatewayProxyResponse();
                    Console.WriteLine(" else request:  " + JsonConvert.SerializeObject(request));
                 
                    Console.WriteLine("Lamda finished");
                    res.Body = "Request is Invalid";
                    return res;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("request:  " + JsonConvert.SerializeObject(request));
                Console.WriteLine(ex.Message);
                Console.WriteLine("Lamda finished");
                APIGatewayProxyResponse res = new APIGatewayProxyResponse();
                res.Body = ex.Message;
                return res;
            }
          


        }
        private async Task<APIGatewayProxyResponse> CopyingObjectAsync(dynamic requestevent, ILambdaContext context)
        {
            APIGatewayProxyResponse res = new APIGatewayProxyResponse();
            string objectkey = Convert.ToString(requestevent.Records[0].s3.@object.key);


            if (objectkey!=null)
            {
                string folderkey = objectkey.Substring(0, objectkey.LastIndexOf("/")) + "/";

                string contentType ="";
                new FileExtensionContentTypeProvider().TryGetContentType(objectkey, out contentType);
                try

                {
                    CopyObjectRequest request = new CopyObjectRequest
                    {
                        
                        SourceBucket = sourcebucket,
                        SourceKey = objectkey,
                        DestinationBucket = destinationbucket,
                        DestinationKey = objectkey,
                        ContentType=contentType,
                };
                   request.Metadata.Add("Content-Type", contentType);
                    CopyObjectResponse response = await s3Client.CopyObjectAsync(request);

                    if (PushMetaAPI(Convert.ToString(objectkey), context))
                    {
                        DeleteObjectRequest deleterequest = new DeleteObjectRequest
                        {
                            BucketName = sourcebucket,
                            Key = objectkey
                        };
                        DeleteObjectResponse deleteResponse = await s3Client.DeleteObjectAsync(deleterequest);

                        DeleteObjectRequest deletefolderrequest = new DeleteObjectRequest
                        {
                            BucketName = sourcebucket,
                            Key = folderkey
                        };
                        DeleteObjectResponse deletefolderrsponse = await s3Client.DeleteObjectAsync(deletefolderrequest);

                        res.StatusCode = 200;
                        res.Body = "success";
                        res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };

                    }
                    else
                    {

                        res.Body = "Api Error";
                        res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };
                        res.StatusCode = 400;
                    }


                }
                catch (AmazonS3Exception e)
                {
                    res.StatusCode = 400;
                    res.Body = e.Message;
                    res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };

                }
            }
            return res;
        }


        private bool PushMetaAPI(string key, ILambdaContext context)
        {
            context.Logger.Log("--Xview API Start--");

            bool pushapival = false;
         
            requestdata objrequest = new requestdata();
            try
            {
                string[] objectList = key.Split("/");
              
                if (objectList.Length >= 0)
                {
                    string[] filename = objectList[2].Split("_");
                    if (filename.Length > 0)
                    {
                        string labno = Convert.ToString(filename[1]);
                        if (labno != string.Empty)
                        {
                            XcubeApi objxcube = new XcubeApi();
                            attributes att = new attributes();
                            att.lab_code = Convert.ToString(objectList[1]);
                            att.file_path = key;
                            att.lab_number = labno;
                            objrequest.attributes = att;
                            HttpStatusCode statuscode;
                            dynamic response = objxcube.PushMetaData(objrequest, context, out statuscode);

                            context.Logger.Log("--Request--");
                            context.Logger.Log(JsonConvert.SerializeObject(objrequest));
                            context.Logger.Log("--Response--");
                            context.Logger.Log(response);
                            context.Logger.Log("--Xview API End--");

                            if (statuscode == HttpStatusCode.OK)
                            {
                                pushapival = true;
                            }
                        }
                        else
                        {
                            context.Logger.Log("--Request--");
                            context.Logger.Log(JsonConvert.SerializeObject(objrequest));
                            context.Logger.Log("--Response--");
                            context.Logger.Log("labno length error");
                            context.Logger.Log("--Xview API End--");
                        }
                    }
                    else
                    {
                        context.Logger.Log("--Request--");
                        context.Logger.Log(JsonConvert.SerializeObject(objrequest));
                        context.Logger.Log("--Response--");
                        context.Logger.Log("filename length error");
                        context.Logger.Log("--Xview API End--");
                    }
                }
                else
                {
                    context.Logger.Log("--Request--");
                    context.Logger.Log(JsonConvert.SerializeObject(objrequest));
                    context.Logger.Log("--Response--");
                    context.Logger.Log("filepath length error");
                    context.Logger.Log("--Xview API End--");
                }
            }
            catch (Exception ex)
            {

                var jsonorderrequest = JsonConvert.SerializeObject(objrequest);
                
                context.Logger.Log("--Response--");
                context.Logger.Log(ex.Message);
                context.Logger.Log("--Xview API End--");
                pushapival = false;
            }

            return pushapival;

        }

      

        //public async  void createlog(string logcontent)
        //{
        //    StringBuilder oldcontent=new StringBuilder() ;
        //    ListObjectsRequest requestx = new ListObjectsRequest();
        //    requestx.BucketName = logbucket;
        //    ListObjectsResponse responsex = await s3Client.ListObjectsAsync(requestx);
        //    foreach (S3Object o in responsex.S3Objects)
        //    {
        //        if (!o.Key.Contains(DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString("yyyyMMdd")))
        //        {

        //            PutObjectRequest FirstPutrequest = new PutObjectRequest();
        //            FirstPutrequest.BucketName = logbucket;
        //            FirstPutrequest.Key = DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString("yyyyMMdd") + @".txt";
        //            FirstPutrequest.ContentType = "text/plain";
        //            FirstPutrequest.ContentBody = "\n" + DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString() + " ==>" + logcontent;
        //            PutObjectResponse Firstresponse = await s3Client.PutObjectAsync(FirstPutrequest);

        //        }
        //    }


        //    try
        //    {
        //        GetObjectRequest Getrequest = new GetObjectRequest();
        //        Getrequest.BucketName = logbucket;
        //        Getrequest.Key = DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString("yyyyMMdd") + @".txt";

        //        GetObjectResponse response = await s3Client.GetObjectAsync(Getrequest);

        //        StreamReader reader = new StreamReader(response.ResponseStream);
        //        oldcontent.Append(reader.ReadToEnd());

        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    oldcontent.Append("\n" + DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString() + " ==>" + logcontent);

        //    PutObjectRequest Putrequest = new PutObjectRequest();
        //    Putrequest.BucketName = logbucket;
        //    Putrequest.Key = DateTime.UtcNow.AddHours(5).AddMinutes(30).ToString("yyyyMMdd") + @".txt";
        //    Putrequest.ContentType = "text/plain";
        //    Putrequest.ContentBody = Convert.ToString(oldcontent);
        //    PutObjectResponse response1 = await s3Client.PutObjectAsync(Putrequest);
        //}


    }


  
       
    
}
    

