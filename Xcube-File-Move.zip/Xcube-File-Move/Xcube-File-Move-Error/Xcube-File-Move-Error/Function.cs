using System.Collections.Generic;
using System.Linq;
using System.Net;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Data.SqlClient;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace Xcube_File_Move_Error
{
    public class Functions
    {
       // private string sourcebucket =  Environment.GetEnvironmentVariable("sourcebucket");// "lalpathlabs-reports-temp1";//lalpathlabs-reports-temp/Mphrx_csv  /
        //private string sourceprefix = Environment.GetEnvironmentVariable("sourceprefix");//FarEye //
      
        private static readonly RegionEndpoint bucketRegion = RegionEndpoint.APSouth1;
        private static IAmazonS3 s3Client;

       
        public string Get(APIGatewayProxyRequest request, ILambdaContext context)
        {
            // DB Connection Variables
            string server = "awsrds.cjbth4s12jgu.ap-south-1.rds.amazonaws.com,1433";//Environment.GetEnvironmentVariable("DB_ENDPOINT");
            string database = "test";// Environment.GetEnvironmentVariable("DATABASE");
            string username = "admin"; //Environment.GetEnvironmentVariable("USER");
            string pwd = "admin1234";//Environment.GetEnvironmentVariable("PASSWORD");
            string ConnectionString = String.Format("Data Source={0};Initial Catalog={1};User ID={2};Password={3}", server, database, username, pwd);

            int count = 3;
            string books = "Books:";

          
            List<dynamic> myDbItems = new List<dynamic>(3);

            using (var Conn = new SqlConnection(ConnectionString))
            {
                using (var Cmd = new SqlCommand($"SELECT top {count} * from books", Conn))
                {
                    // Open SQL Connection
                    Conn.Open();

                    // Execute SQL Command
                    SqlDataReader rdr = Cmd.ExecuteReader();

                    // Loop through the results and add to list
                    while (rdr.Read())
                    {
                        myDbItems.Add(rdr[1].ToString());
                    }
                    // Generate Output
                    for (int i = 0; i < myDbItems.Count; i++)
                    {
                        books += $" {myDbItems[i]}";
                        // Add a comma if it's not the last item
                        if (i != myDbItems.Count - 1)
                        {
                            books += ",";
                        }
                    }
                }
            }
            // Return the value
            return books;
            //context.Logger.LogLine("Lamda started");
            
            //s3Client = new AmazonS3Client(bucketRegion);
            //Task<APIGatewayProxyResponse> results = CopyingObjectAsync(context);
            //context.Logger.LogLine(results.Result.Body);
            //context.Logger.LogLine("Lamda finished");
            //return results.Result;
        }
        //private async Task<APIGatewayProxyResponse> CopyingObjectAsync(ILambdaContext context)
        //{
        //    Regex rgx = new Regex("[^A-Za-z0-9_.]");

        //    APIGatewayProxyResponse res = new APIGatewayProxyResponse();
        //    ListObjectsV2Request sourceobjectrequest = new ListObjectsV2Request
        //    {
                
        //        BucketName = sourcebucket,
        //        Prefix = sourceprefix + "/" //"FarEye/"
        //    };


        //    ListObjectsV2Response responseobject;


        //    do
        //    {
        //        responseobject = await s3Client.ListObjectsV2Async(sourceobjectrequest);
        //        Console.WriteLine(responseobject.KeyCount);
        //        // Process the response.
        //        if (responseobject.KeyCount > 0)
        //        {
        //            foreach (S3Object entry in responseobject.S3Objects)
        //            {
        //                Console.WriteLine(entry.Key + ":" + entry.LastModified);
        //                string[] objectList = entry.Key.Split("/");
                     

        //                    if (entry.LastModified <= DateTime.Now.AddMinutes(-2))
        //                    {
        //                    if (objectList.Length >= 3)
        //                    {
        //                        if (rgx.IsMatch(objectList[2].ToString()))
        //                        {
        //                            Console.WriteLine("regex error");
                                   
                                   
        //                            try
        //                            {
                                     
        //                                    PutObjectRequest putRequest = new PutObjectRequest
        //                                    {
        //                                        BucketName = sourcebucket,
        //                                        Key = (sourceprefix.Trim() + "/" + objectList[1] + "/" + Regex.Replace(objectList[2], "[^a-zA-Z0-9._]+", "", RegexOptions.Compiled)),
                                              
        //                                    };
        //                                    PutObjectResponse response = await s3Client.PutObjectAsync(putRequest);

        //                                DeleteObjectRequest deleterequest = new DeleteObjectRequest
        //                                    {
        //                                        BucketName = sourcebucket,
        //                                        Key = ("/" + sourceprefix.Trim() + "/" + objectList[1] + "/" + objectList[2])
        //                                };

        //                                    DeleteObjectResponse deleteResponse = await s3Client.DeleteObjectAsync(deleterequest);
        //                                    res.StatusCode = 200;
        //                                    res.Body = "success";
        //                                    res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };
                                       

        //                            }
        //                            catch (AmazonS3Exception e)
        //                            {
        //                                res.StatusCode = 400;
        //                                res.Body = e.Message;
        //                                res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };

        //                            }
        //                            catch (WebException e)
        //                            {
        //                                res.StatusCode = 400;
        //                                res.Body = e.Message;
        //                                res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };

        //                            }
        //                        }
        //                        }
        //                    }
                       
        //            }
        //        }
        //        else
        //        {
        //            res.StatusCode = 200;
        //            res.Body = "File(s) Not Found.";
        //            res.Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } };
        //        }

        //    } while (responseobject.IsTruncated);

        //    return res;
        //}

      


    }
}
